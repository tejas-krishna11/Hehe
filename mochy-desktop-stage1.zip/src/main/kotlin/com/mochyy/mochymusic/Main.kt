// Main.kt

package com.mochyy.mochymusic

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.res.loadImageBitmap
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import com.mochyy.mochymusic.ui.openResource
import com.mochyy.mochymusic.ui.theme.MochyTheme
import java.awt.Dimension

fun main() = application {
    // phone-shaped to start with, like the Android app; resize or maximise freely
    val windowState = rememberWindowState(size = DpSize(440.dp, 740.dp))
    val windowIcon = remember { BitmapPainter(openResource("icon.png").use { loadImageBitmap(it) }) }

    Window(
        onCloseRequest = ::exitApplication,
        state = windowState,
        title = "Mochy",
        icon = windowIcon,
    ) {
        LaunchedEffect(window) {
            window.minimumSize = Dimension(360, 600)
        }
        MochyTheme {
            MochyApp()
        }
    }
}
