// Type.kt

package com.mochyy.mochymusic.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.platform.Font
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

private val Inter = FontFamily(
    Font(resource = "fonts/inter_thin.ttf", weight = FontWeight.Thin),
    Font(resource = "fonts/inter_extralight.ttf", weight = FontWeight.ExtraLight),
    Font(resource = "fonts/inter_light.ttf", weight = FontWeight.Light),
    Font(resource = "fonts/inter_regular.ttf", weight = FontWeight.Normal),
    Font(resource = "fonts/inter_medium.ttf", weight = FontWeight.Medium),
    Font(resource = "fonts/inter_semibold.ttf", weight = FontWeight.SemiBold),
    Font(resource = "fonts/inter_bold.ttf", weight = FontWeight.Bold),
)

/** a look module's font, standing in for inter across the app while that look is on; null is inter */
object LookFont {
    var family: FontFamily? by mutableStateOf(null)
}

// read through a state, so text set in it follows a look's font turning on or off
val InterFontFamily: FontFamily get() = LookFont.family ?: Inter

// same two global choices as the Android app: everything semibold, tracking pulled in
private val GlobalFontWeight = FontWeight.SemiBold
private val GlobalLetterSpacing = (-0.05).em

private fun style(font: FontFamily, size: Int, line: Int) = TextStyle(
    fontFamily = font,
    fontWeight = GlobalFontWeight,
    fontSize = size.sp,
    lineHeight = line.sp,
    letterSpacing = GlobalLetterSpacing,
)

/** the app's text styles in [font], rebuilt when a look's font comes or goes */
fun appTypography(font: FontFamily) = Typography(
    displayLarge = style(font, 57, 64),
    displayMedium = style(font, 45, 52),
    displaySmall = style(font, 36, 44),
    headlineLarge = style(font, 32, 40),
    headlineMedium = style(font, 28, 36),
    headlineSmall = style(font, 24, 32),
    titleLarge = style(font, 22, 28),
    titleMedium = style(font, 16, 24),
    titleSmall = style(font, 14, 20),
    bodyLarge = style(font, 16, 24),
    bodyMedium = style(font, 14, 20),
    bodySmall = style(font, 12, 16),
    labelLarge = style(font, 14, 20),
    labelMedium = style(font, 12, 16),
    labelSmall = style(font, 11, 16),
)
