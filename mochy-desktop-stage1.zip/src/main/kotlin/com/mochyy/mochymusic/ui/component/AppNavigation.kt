// AppNavigation.kt

package com.mochyy.mochymusic.ui.component

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.input.pointer.pointerHoverIcon
import androidx.compose.ui.unit.dp
import com.mochyy.mochymusic.ui.rememberSvgPainter
import com.mochyy.mochymusic.ui.screens.Screen
import kotlinx.coroutines.launch

/** The bar itself, a stadium the mini player's 64dp matches. */
internal val NavBarHeight = 64.dp
internal val NavBarShape = RoundedCornerShape(50)
internal val NavBarMaxWidth = 440.dp

/** surface of the floating bars; the Android app draws glass here, this is a flat stand-in for now */
internal val BarSurface = Color(0xFF141414)
internal val BarOutline = Color.White.copy(alpha = 0.10f)

private val NavHighlightInset = 8.dp
private val NavHighlightColor = Color.White.copy(alpha = 0.14f)
private const val UnlitIconAlpha = 0.55f

// The highlight's front edge springs to the new tab faster than its back edge, so it stretches
// on the way and then settles - the same two springs the Android app uses.
private val NavHighlightLead = spring<Float>(dampingRatio = 0.82f, stiffness = 700f)
private val NavHighlightTrail = spring<Float>(dampingRatio = 0.82f, stiffness = 320f)

@Composable
fun MochyNavBar(
    items: List<Screen>,
    selected: Screen,
    onSelect: (Screen) -> Unit,
    modifier: Modifier = Modifier,
) {
    val selectedIndex = items.indexOf(selected)
    val start = remember { Animatable(selectedIndex.toFloat()) }
    val end = remember { Animatable(selectedIndex + 1f) }

    LaunchedEffect(selectedIndex) {
        val movingRight = selectedIndex + 1f > end.value
        launch {
            start.animateTo(selectedIndex.toFloat(), if (movingRight) NavHighlightTrail else NavHighlightLead)
        }
        launch {
            end.animateTo(selectedIndex + 1f, if (movingRight) NavHighlightLead else NavHighlightTrail)
        }
    }

    Row(
        modifier = modifier
            .widthIn(max = NavBarMaxWidth)
            .fillMaxWidth()
            .height(NavBarHeight)
            .clip(NavBarShape)
            .background(BarSurface)
            .drawBehind {
                val tabWidth = size.width / items.size
                val inset = NavHighlightInset.toPx()
                val left = start.value * tabWidth + inset
                val right = end.value * tabWidth - inset
                val height = size.height - inset * 2f
                if (right > left) {
                    drawRoundRect(
                        color = NavHighlightColor,
                        topLeft = Offset(left, inset),
                        size = Size(right - left, height),
                        cornerRadius = CornerRadius(height / 2f),
                    )
                }
            }
            .border(1.dp, BarOutline, NavBarShape),
    ) {
        items.forEach { screen ->
            NavItem(
                screen = screen,
                isSelected = screen == selected,
                onClick = { onSelect(screen) },
            )
        }
    }
}

@Composable
private fun RowScope.NavItem(
    screen: Screen,
    isSelected: Boolean,
    onClick: () -> Unit,
) {
    val lit by animateFloatAsState(if (isSelected) 1f else 0f, tween(200), label = "navLit")
    val inactivePainter = rememberSvgPainter(screen.iconInactive)
    val activePainter = rememberSvgPainter(screen.iconActive)
    val iconSize = if (screen == Screen.Library) 24.dp else 22.dp

    Box(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .pointerHoverIcon(PointerIcon.Hand)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = inactivePainter,
            contentDescription = screen.label,
            colorFilter = ColorFilter.tint(Color.White),
            alpha = UnlitIconAlpha * (1f - lit),
            modifier = Modifier.size(iconSize),
        )
        Image(
            painter = activePainter,
            contentDescription = null,
            colorFilter = ColorFilter.tint(Color.White),
            alpha = lit,
            modifier = Modifier.size(iconSize),
        )
    }
}
