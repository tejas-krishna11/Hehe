// Placeholders.kt

package com.mochyy.mochymusic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mochyy.mochymusic.ui.theme.bbhBartle

// room left at the bottom so content scrolls clear of the floating mini player + nav bar
private val BottomBarsClearance = 200.dp

@Composable
private fun ScreenColumn(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(start = 24.dp, end = 24.dp, top = 40.dp, bottom = BottomBarsClearance),
    ) {
        content()
    }
}

@Composable
private fun ScreenTitle(text: String) {
    Text(text = text, style = MaterialTheme.typography.headlineLarge)
    Spacer(Modifier.height(20.dp))
}

@Composable
private fun InfoCard(title: String, lines: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(text = title, style = MaterialTheme.typography.titleMedium)
        lines.forEach { line ->
            Text(
                text = line,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.7f),
            )
        }
    }
}

@Composable
fun HomeScreen() {
    ScreenColumn {
        Text(text = "mochy", fontFamily = bbhBartle, fontSize = 44.sp)
        Text(
            text = "for PC",
            style = MaterialTheme.typography.titleMedium,
            color = Color.White.copy(alpha = 0.6f),
        )
        Spacer(Modifier.height(28.dp))
        InfoCard(
            title = "Stage 1: desktop foundation",
            lines = listOf(
                "Done: window, theme, fonts, navigation bar and the cloud build.",
                "Next: search and playback, then Crossmix.",
            ),
        )
    }
}

@Composable
fun SearchScreen() {
    ScreenColumn {
        ScreenTitle("Search")
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .clip(RoundedCornerShape(50))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 24.dp),
            contentAlignment = androidx.compose.ui.Alignment.CenterStart,
        ) {
            Text(
                text = "Search songs, albums, artists",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.5f),
            )
        }
    }
}

@Composable
fun LibraryScreen() {
    ScreenColumn {
        ScreenTitle("Your library")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Playlists", "Albums", "Artists").forEach { chip ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                ) {
                    Text(text = chip, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}
