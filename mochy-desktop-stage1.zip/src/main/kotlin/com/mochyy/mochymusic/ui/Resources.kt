// Resources.kt

package com.mochyy.mochymusic.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.loadSvgPainter
import java.io.InputStream

/** opens a file bundled in src/main/resources, failing loudly if it is missing */
fun openResource(path: String): InputStream {
    val loader = Thread.currentThread().contextClassLoader ?: ClassLoader.getSystemClassLoader()
    return checkNotNull(loader.getResourceAsStream(path)) { "Missing bundled resource: $path" }
}

/** the app's own SVG icons (the same files the Android app ships), as a painter */
@Composable
fun rememberSvgPainter(path: String): Painter {
    val density = LocalDensity.current
    return remember(path, density) {
        openResource(path).use { loadSvgPainter(it, density) }
    }
}
