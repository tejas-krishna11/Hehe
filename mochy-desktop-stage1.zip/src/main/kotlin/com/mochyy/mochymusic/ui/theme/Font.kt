// Font.kt

package com.mochyy.mochymusic.ui.theme

import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.platform.Font

val bbhBartle = FontFamily(
    Font(resource = "fonts/bbh_bartle_regular.ttf", weight = FontWeight.Normal)
)
