// Screens.kt

package com.mochyy.mochymusic.ui.screens

/** the three top-level tabs, with the same icons and routes the Android app uses */
enum class Screen(
    val label: String,
    val route: String,
    val iconInactive: String,
    val iconActive: String,
) {
    Home("Home", "home", "icons/home.svg", "icons/home_filled.svg"),
    Search("Search", "search_input", "icons/search.svg", "icons/search_filled.svg"),
    Library("Your library", "library", "icons/lib.svg", "icons/lib_fill.svg"),
}
