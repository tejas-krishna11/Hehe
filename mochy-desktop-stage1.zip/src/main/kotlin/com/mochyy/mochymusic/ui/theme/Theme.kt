// Theme.kt

package com.mochyy.mochymusic.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color

val DefaultThemeColor = Color(0xFF8E8E8E)

/** mochy renders dark-only, exactly as the Android app does */
const val ForceDarkTheme = true

@Composable
fun MochyTheme(
    darkTheme: Boolean = ForceDarkTheme,
    pureBlack: Boolean = false,
    content: @Composable () -> Unit,
) {
    val baseColorScheme = if (darkTheme) {
        darkColorScheme(
            primary = Color(0xFFE0E0E0),
            onPrimary = Color.Black,
            primaryContainer = Color(0xFF333333),
            onPrimaryContainer = Color.White,
            secondary = Color(0xFFB0B0B0),
            onSecondary = Color.Black,
            secondaryContainer = Color(0xFF2C2C2C),
            onSecondaryContainer = Color.White,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color.Black,
            onSurface = Color.White,
            surfaceVariant = Color(0xFF1A1A1A),
            onSurfaceVariant = Color.White,
            surfaceTint = Color.Black,
        )
    } else {
        lightColorScheme(
            primary = Color.Black,
            onPrimary = Color.White,
            primaryContainer = Color(0xFFE0E0E0),
            onPrimaryContainer = Color.Black,
            secondary = Color(0xFF333333),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFCCCCCC),
            onSecondaryContainer = Color.Black,
            background = Color.White,
            onBackground = Color.Black,
            surface = Color.White,
            onSurface = Color.Black,
            surfaceVariant = Color(0xFFF0F0F0),
            onSurfaceVariant = Color.Black,
            surfaceTint = Color.White,
        )
    }

    val colorScheme = remember(baseColorScheme, pureBlack, darkTheme) {
        if (darkTheme && pureBlack) baseColorScheme.pureBlack(true) else baseColorScheme
    }

    val font = InterFontFamily
    val typography = remember(font) { appTypography(font) }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
    ) {
        ProvideTextStyle(
            value = typography.bodyLarge,
            content = content,
        )
    }
}

fun ColorScheme.pureBlack(apply: Boolean) =
    if (apply) copy(surface = Color.Black, background = Color.Black) else this
