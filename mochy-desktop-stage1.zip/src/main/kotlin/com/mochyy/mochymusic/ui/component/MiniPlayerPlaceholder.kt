// MiniPlayerPlaceholder.kt

package com.mochyy.mochymusic.ui.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/**
 * Stand-in for the real mini player (stage 2 wires it to playback). Same 64dp stadium as the
 * navigation bar, so the two stack the way they do in the Android app.
 */
@Composable
fun MiniPlayerPlaceholder(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .widthIn(max = NavBarMaxWidth)
            .fillMaxWidth()
            .height(NavBarHeight)
            .clip(NavBarShape)
            .background(BarSurface)
            .border(1.dp, BarOutline, NavBarShape)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xFF2C2C2C)),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = "Nothing playing",
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = "Mochy for PC",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Canvas(Modifier.size(44.dp)) {
            drawCircle(Color.White)
            val triangle = Path().apply {
                moveTo(size.width * 0.40f, size.height * 0.30f)
                lineTo(size.width * 0.40f, size.height * 0.70f)
                lineTo(size.width * 0.72f, size.height * 0.50f)
                close()
            }
            drawPath(triangle, Color.Black)
        }
    }
}
