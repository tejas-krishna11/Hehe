// App.kt

package com.mochyy.mochymusic

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mochyy.mochymusic.ui.component.MiniPlayerPlaceholder
import com.mochyy.mochymusic.ui.component.MochyNavBar
import com.mochyy.mochymusic.ui.screens.HomeScreen
import com.mochyy.mochymusic.ui.screens.LibraryScreen
import com.mochyy.mochymusic.ui.screens.Screen
import com.mochyy.mochymusic.ui.screens.SearchScreen

@Composable
fun MochyApp() {
    var current by remember { mutableStateOf(Screen.Home) }

    // Surface supplies the content colour, otherwise text defaults to black on the black background
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground,
    ) {
        Box(Modifier.fillMaxSize()) {
            Crossfade(
                targetState = current,
                animationSpec = tween(200),
                label = "tab",
            ) { screen ->
                when (screen) {
                    Screen.Home -> HomeScreen()
                    Screen.Search -> SearchScreen()
                    Screen.Library -> LibraryScreen()
                }
            }

            // mini player stacked over the nav bar, both floating at the bottom
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                MiniPlayerPlaceholder()
                MochyNavBar(
                    items = Screen.entries,
                    selected = current,
                    onSelect = { current = it },
                )
            }
        }
    }
}
