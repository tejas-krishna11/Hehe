import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "2.1.21"
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.21"
    id("org.jetbrains.compose") version "1.8.2"
}

group = "com.mochyy.mochymusic"
version = "1.0.0"

dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.runtime)
    implementation(compose.foundation)
    implementation(compose.ui)
    implementation(compose.animation)
    implementation(compose.material3)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.10.2")
}

compose.desktop {
    application {
        mainClass = "com.mochyy.mochymusic.MainKt"

        nativeDistributions {
            targetFormats(TargetFormat.Exe, TargetFormat.Msi)
            packageName = "Mochy"
            packageVersion = "1.0.0"
            description = "Mochy Music for PC"
            vendor = "Mochy Music desktop port"
            // keeps every JDK module in the bundled runtime, so libraries added in later
            // stages (networking, database, audio) never hit a missing-module crash
            includeAllModules = true

            windows {
                iconFile.set(project.file("packaging/icon.ico"))
                shortcut = true
                menuGroup = "Mochy"
                perUserInstall = true
                dirChooser = true
                upgradeUuid = "cf9dcd10-9785-4a2a-8d22-36007fb640d1"
            }
        }
    }
}
