# Mochy for PC: stage 1

You do not need to install anything on your PC. GitHub builds the Windows app for you, in the cloud, for free.

## 1. Make a free GitHub account
Go to https://github.com and sign up (skip this if you already have one).

## 2. Create a repository
- Click the **+** at the top right, then **New repository**
- Name: `mochy-desktop`
- Choose **Private** (only you can see it)
- Click **Create repository**

## 3. Upload this project
- Unzip the file you downloaded first.
- On the new repository page, click **uploading an existing file**.
- Open the unzipped folder and select EVERYTHING inside it (all folders and files, not the zip),
  then drag it into the browser window.
- Wait until all files have uploaded, then click **Commit changes**.

Check: the repository page should now show a folder called `.github`.
If it is missing: click **Add file > Create new file**, type `.github/workflows/build.yml` as the name,
paste the whole content of `build-workflow-copy.yml` into the big box, and click **Commit changes**.

## 4. Build the app
- Click the **Actions** tab. If GitHub asks, click the green button to enable workflows.
- Click **Build Windows app** on the left, then **Run workflow** (green button, on the right) and confirm.
- Wait about 10 to 15 minutes. A green tick means it worked.

## 5. Download and run it
- Click the finished run, scroll to **Artifacts** at the bottom.
- Download **Mochy-Windows-portable**, unzip it, and open `Mochy.exe`.
- Windows may say "Windows protected your PC" because the app is not signed.
  Click **More info**, then **Run anyway**.
- **Mochy-Windows-installer** is a normal installer, if that step succeeded.

## If the build fails (red cross)
Click the failed run, click the red step, copy the error text, and send it to Claude.
First builds of a new project often need a fix or two.

---
Mochy Music is by realidkroo and licensed GPL-3.0. This desktop port is a derivative work and is
also GPL-3.0 (see LICENSE). If you share the .exe with others, you must also share the source.
